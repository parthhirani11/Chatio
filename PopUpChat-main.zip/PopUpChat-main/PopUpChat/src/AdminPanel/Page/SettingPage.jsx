import SettingCom from "../Components/SettingCom";


export default function SettingPage() {
  return (
    <div className="p-5 col-span-5">
       <SettingCom />
    </div>
  )
}
