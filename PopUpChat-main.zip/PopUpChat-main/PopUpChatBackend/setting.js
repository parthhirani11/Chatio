export const email ="ranahardik722@gmail.com";
export const password ="vdtgdiiajgujofuv";
export const secratekey = "This is a secrate key";
export const IV = "This is a IV";