/** @type {import('tailwindcss').Config} */
export default {
  content: [],
  darkMode:"class",
  important:true,
  theme: {
    extend: {},
  },
  plugins: [],
}

