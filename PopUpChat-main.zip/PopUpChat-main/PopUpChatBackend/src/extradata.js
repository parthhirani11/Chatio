// setTimeout(() => {
//     body.innerHTML += `
//     <div>
//     <button id="close"
//         class="hidden float-right text-white h-8 w-8 bg-blue-700 rounded-full p-2 my-auto mr-5 hover:bg-blue-800"><img
//             src="https://img.icons8.com/ios-filled/50/FFFFFF/delete-sign--v1.png" alt="delete-sign--v1"></button>

//     <div class="h-14 w-14 shadow-xl rounded-full fixed bottom-0 right-0 m-6 drop-shadow-lg hover:shadow-xl overflow-hidden"
//         id="chatio">
//         <img src="https://cryptologos.cc/logos/chatcoin-chat-logo.png" class="" alt="not" id="chatimg">
//         <div class="hidden" id="chat">
//             <div class="h-20 bg-blue-700 flex pl-3 justify-between">
//                 <div class="flex">
//                     <img class="rounded-full h-14 w-14 my-auto"
//                         src="https://static.vecteezy.com/system/resources/previews/011/381/911/original/male-customer-service-3d-cartoon-avatar-portrait-png.png"
//                         alt="not found">
//                     <div class="my-auto">
//                         <p class="font-semibold text-lg text-center text-white">Rana Hardik</p>
//                         <div class="flex mt-1">
//                             <span class="h-2 w-2 rounded-full bg-white animate-ping my-auto mr-2"></span>
//                             <p class="text-xs text-white">Online</p>
//                         </div>
//                     </div>
//                 </div>



//             </div>
//             <div class="h-96 w-full overflow-y-scroll pb-20 " id="msg">

//             </div>
//             <div class="p-4 fixed bottom-0 w-full bg-blue-100">
//                 <div class="flex w-full hidden" id="inputs">
//                     <input type="text" id="msginput" placeholder="Message"
//                         class="placeholder-white w-full text-white py-2 px-2 rounded-lg bg-blue-700 ring-1 ring-slate-100 outline-none">
//                     <button id="sendmsg" class="h-10 w-11 ml-1 bg-blue-700 rounded-full hover:bg-blue-800"><img
//                             class="p-2" src="https://img.icons8.com/ios-glyphs/100/FFFFFF/sent.png"
//                             alt="not"></button>
//                 </div>
//                 <button id="chatnowbtn"
//                     class="bg-blue-700 text-white font-semibold w-full py-2 rounded-xl hover:bg-blue-800">Chat
//                     Now</button>
//             </div>
//         </div>

//     </div>
// </div>

// `

// }, 2000);